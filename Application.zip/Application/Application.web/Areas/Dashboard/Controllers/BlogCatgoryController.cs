﻿using Application.Domain;
using Application.Service;
using Application.web.Areas.Dashboard.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.web.Areas.Dashboard.Controllers
{
    public class BlogCatgoryController : Controller
    {

        private IBlogCatgoryService _service { get; }
        public BlogCatgoryController(IBlogCatgoryService service)
        {
            _service = service;
        }


        // Get Create
        public ActionResult Create()
        {
            BlogCatgoryModel entity = new BlogCatgoryModel();

            return
                View(entity);
        }

        [HttpPost]

        // Post Create

        public ActionResult Create(BlogCatgoryModel entity)
        {
            BlogCatgory model = new BlogCatgory();

            if (ModelState.IsValid)
            {
                model.Name = entity.Name;

                _service.Create(model);

                return
                RedirectToAction("Index");
            }

            return
                View(entity);
        }

        // Get Edit 

        public ActionResult Edit(int id)
        {
            BlogCatgory entity = _service.Find(id);
            BlogCatgoryModel model = new BlogCatgoryModel();

            model.Id = entity.Id;
            model.Name = entity.Name;

            return
                View(model);
        }

        [HttpPost]

        // Post Edit

        public ActionResult Edit(BlogCatgoryModel entity ,int id)
        {
            id = entity.Id;
            BlogCatgory md = _service.Find(id);

            if (ModelState.IsValid)
            {
                md.Name = entity.Name;

                _service.Edit(md);

                return
                    RedirectToAction("Index");
            }
            return
                View(entity);
        }

        // Get Delete

        public ActionResult Delete(int id)
        {
            BlogCatgory entity = _service.Find(id);
            BlogCatgoryModel model = new BlogCatgoryModel();

            model.Id = entity.Id;
            model.Name = entity.Name;

            return
                View(model);
        }

        [HttpPost,ActionName("Delete")]
        // Post Delete

        public ActionResult DeleteConfirmed(int id)
        {
            BlogCatgory entity = _service.Find(id);

            _service.Delete(entity);

            return
                RedirectToAction("Index");
        }

        // Just Get List

        public ActionResult List()
        {
            List<BlogCatgory> entity = _service.List();
            List<BlogCatgoryModel> model = new List<BlogCatgoryModel>();

            foreach(BlogCatgory item in entity)
            {
                BlogCatgoryModel md = new BlogCatgoryModel();

                md.Id = item.Id;
                md.Name = item.Name;


                model.Add(md);
            }
            return
                PartialView("_List", model);
        }
        

        // Just Get Details
        public ActionResult Details(int id)
        {
            BlogCatgory entity = _service.Find(id);
            BlogCatgoryModel model = new BlogCatgoryModel();

            model.Id = entity.Id;
            model.Name = entity.Name;

            return
                View(model);
        }

        // Other Methods
        public ActionResult Index()
        {
            return View();
        }
    }
}