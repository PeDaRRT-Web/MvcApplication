﻿using Application.Domain;
using Application.Service;
using Application.web.Areas.Dashboard.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.web.Areas.Dashboard.Controllers
{
    public class BlogController : Controller
    {
        // Lazing Loding
        private IBlogService _service { get; }
        private IBlogCatgoryService _cat { get; }
        public BlogController(IBlogService Reposit, IBlogCatgoryService Cat)
        {
            _service = Reposit;
            _cat = Cat;
        }


        // Get Create
        public ActionResult Create()
        {
            BlogModel model = new BlogModel();
            List<BlogCatgory> entity = _cat.List();

            foreach (var item in entity)
            {
                model.CatgoryList.Add(new SelectListItem()
                {
                    Text = item.Name,
                    Value = item.Id.ToString()
                });
            }

            return
                View(model);

        }

        [HttpPost]

        // Post Create
        public ActionResult Create(BlogModel entity)
        {
            List<BlogCatgory> model = _cat.List();
            Blog md = new Blog();
            foreach (var item in model)
            {
                entity.CatgoryList.Add(new SelectListItem()
                {
                    Text = item.Name,
                    Value = item.Id.ToString()
                });
            }

            if (ModelState.IsValid)
            {
                md.Name = entity.Name;
                md.Img = entity.Img;
                md.Descraption = entity.Descraption;
                md.BlogCatgoryId = entity.BlogCatgoryId;

                _service.Create(md);

                return
                    RedirectToAction("Index");
            }
            return
                View(entity);
        }
        
        // Get Edit
        public ActionResult Edit(int id)
        {
            Blog model = _service.Find(id);
            List<BlogCatgory> md = _cat.List();
            BlogModel entity = new BlogModel();

            foreach (var item in md)
            {
                entity.CatgoryList.Add(new SelectListItem()
                {
                    Text = item.Name,
                    Value = item.Id.ToString()
                });
            }

            entity.Id = model.Id;
            entity.Name = model.Name;
            entity.Img = model.Img;
            entity.Descraption = model.Descraption;
            entity.BlogCatgoryId = model.BlogCatgoryId;

            return
                View(entity);
        }

        [HttpPost]
        // Post Edit 
        public ActionResult Edit(BlogModel entity, int id)
        {
            id = entity.Id;
            Blog model = _service.Find(id);
            List<BlogCatgory> md = _cat.List();

            foreach(var item in md)
            {
                entity.CatgoryList.Add(new SelectListItem()
                {
                    Text = item.Name,
                    Value = item.Id.ToString()
                });
            }

            if (ModelState.IsValid)
            {
                model.Name = entity.Name;
                model.Img = entity.Img;
                model.Descraption = entity.Descraption;
                model.BlogCatgoryId = entity.BlogCatgoryId;

                _service.Edit(model);
                return
                    RedirectToAction("Index");
            }
            return
                View(entity);
        }
        // Get Delete
        public ActionResult Delete(int id)
        {
            Blog entity = _service.Find(id);
            BlogModel model = new BlogModel();


            model.Id = entity.Id;
            model.Name = entity.Name;
            model.Img = entity.Img;
            model.Descraption = entity.Descraption;
            model.BlogCatgoryId = entity.BlogCatgoryId;

            return
                View(model);

        }

        [HttpPost,ActionName("Delete")]
        // Post Delete
        public ActionResult DeleteConfirmed(int id)
        {
            Blog entity = _service.Find(id);

            _service.Delete(entity);

            return
            RedirectToAction("Index");
        }

        // Just Get List
        public ActionResult List()
        {
            List<Blog> entity = _service.List();
            List<BlogModel> model = new List<BlogModel>();
            foreach(Blog item in entity)
            {
                BlogModel md = new BlogModel();

                md.Id = item.Id;
                md.Name = item.Name;
                md.Img = item.Img;
                md.Descraption = item.Descraption;
                md.BlogCatgoryId = item.BlogCatgoryId;

                model.Add(md);

            }
            return
                PartialView("_List", model);
        }

        // Just Get Details
        
        public ActionResult Details(int id)
        {
            Blog entity = _service.Find(id);
            BlogModel model = new BlogModel();

            model.Id = entity.Id;
            model.Name = entity.Name;
            model.Img = entity.Img;
            model.Descraption = entity.Descraption;
            model.BlogCatgoryId = entity.BlogCatgoryId;

            return
                View(model);
        }

        // Other Methods
        public ActionResult Index()
        {
            return View();
        }
    }
}