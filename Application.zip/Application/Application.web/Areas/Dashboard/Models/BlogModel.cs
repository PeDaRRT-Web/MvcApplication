﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.web.Areas.Dashboard.Models
{
    public class BlogModel
    {
        public BlogModel()
        {
            CatgoryList = new List<SelectListItem>();
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Descraption { get; set; }

        public string Img { get; set; }

        public int BlogCatgoryId { get; set; }

        public List<SelectListItem> CatgoryList { get; set; }
    }
}