﻿using Application.Domain;
using System.Collections.Generic;

namespace Application.Service
{
    public interface IBlogCatgoryService
    {
        void Create(BlogCatgory entity);
        void Delete(BlogCatgory entity);
        void Edit(BlogCatgory entity);
        BlogCatgory Find(int id);
        List<BlogCatgory> List();
    }
}