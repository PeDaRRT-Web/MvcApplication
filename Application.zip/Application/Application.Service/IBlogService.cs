﻿using Application.Domain;
using System.Collections.Generic;

namespace Application.Service
{
    public interface IBlogService
    {
        void Create(Blog entity);
        void Delete(Blog entity);
        void Edit(Blog entity);
        Blog Find(int id);
        List<Blog> List();
    }
}