﻿using Application.Core;
using Application.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Service
{
    public class BlogService : IBlogService
    {
        // Lazing Loding
        private IRepository<Blog> _service { get; }
        public BlogService(IRepository<Blog> Reposit)
        {
            _service = Reposit;
        }


        // Service Create
        public void Create(Blog entity)
        {
            DateTime dt = DateTime.Now;
            entity.Created = dt;
            entity.Updated = dt;

            _service.Create(entity);
        }

        // Service Edit Or Update
        public void Edit(Blog entity)
        {
            entity.Updated = DateTime.Now;

            _service.Edit(entity);
        }


        // Service Delete Or Remove
        public void Delete(Blog entity)
        {
            _service.Delete(entity);
        }


        // Service Find
        public Blog Find(int id)
        {

            return
                _service.Find(id);
        }


        // Service List
        public List<Blog> List()
        {
            return
                _service.List();
        }
    }
}
