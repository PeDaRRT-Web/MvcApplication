﻿using Application.Core;
using Application.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Service
{
    public class BlogCatgoryService : IBlogCatgoryService
    {
        // Lazing Loding
        private IRepository<BlogCatgory> _service { get; }
        public BlogCatgoryService(IRepository<BlogCatgory> Reposit)
        {
            _service = Reposit;
        }


        // Service Create
        public void Create(BlogCatgory entity)
        {

            DateTime Dt = DateTime.Now;
            entity.Created = Dt;
            entity.Updated = Dt;

            _service.Create(entity);
        }


        // Service Edit Or Update
        public void Edit(BlogCatgory entity)
        {
            entity.Updated = DateTime.Now;

            _service.Edit(entity);
        }


        // Service Delete Or Remove
        public void Delete(BlogCatgory entity)
        {
            _service.Delete(entity);
        }


        // Service Find
        public BlogCatgory Find(int id)
        {
            return
                _service.Find(id);
        }


        // Service List
        public List<BlogCatgory> List()
        {
            return
                _service.List();
        }
    }
}
