﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Domain
{
    public class Blog:BaseEntity
    {
        public Blog()
        {

        }

        public string Name { get; set; }

        public string Descraption { get; set; }

        public string Img { get; set; }

        public int BlogCatgoryId { get; set; }
    }
}
