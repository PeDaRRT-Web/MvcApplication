﻿using Application.web.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Core
{
    public class Repository<T> : IRepository<T> where T : class
    {
        // Lazing Loding
        private ApplicationDbContext _context { get; }
        public Repository(ApplicationDbContext Context)
        {
            _context = Context;
        }


        // Repository Create
        public void Create(T entity)
        {
            _context.Set<T>().Add(entity);
            _context.SaveChanges();
        }


        // Repository Edit Or Update
        public void Edit(T entity)
        {
            _context.Set<T>().AddOrUpdate(entity);
            _context.SaveChanges();
        }


        // Repository Delete Or Remove
        public void Delete(T entity)
        {
            _context.Set<T>().Remove(entity);
            _context.SaveChanges();
        }


        // Repository Find
        public T Find(int id)
        {
            return
                _context.Set<T>().Find(id);
        }


        //  Repository List
        public List<T> List()
        {
            return
                _context.Set<T>().ToList();
        }

    }
}
