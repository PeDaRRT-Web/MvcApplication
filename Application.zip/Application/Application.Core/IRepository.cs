﻿using System.Collections.Generic;

namespace Application.Core
{
    public interface IRepository<T> where T : class
    {
        void Create(T entity);
        void Delete(T entity);
        void Edit(T entity);
        T Find(int id);
        List<T> List();
    }
}